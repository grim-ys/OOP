## Project Heartbeat v 1.0

Project Heartbeat is the Final submission for OOP group 0, which Professor Neena Goveas assigned. All 19 team members, under the leadership of Shreyas V., worked on their skills for furnishing this final project. Acquiring many skills and showcasing incredible teamwork to crown Project heartbeat with an original design concept, we have included some unique features, customizable elements and a perfect responsive code.

Project Heartbeat is a well-built cross-platform project that provides a medium to share and receive various documents, medical history and prescriptions while ensuring patient privacy. Doctors can request access, and they can accept the data. This software would help patients when they would shift from one Doctor to another as the new Doctor would easily be able to access the medical history of the patient. There would be a universal Login, and the user will be directed to either the patient's dashboard or the Doctor's dashboard, depending on the type of user.

The patient will get notified if any Doctor requests to access their medical records, and they have the liberty to accept or deny the request. If the user accepts, the Doctor will get access to all the patient's medical records. The Doctor can review and advise the patient accordingly. The Doctor can also schedule an appointment with the patient if needed. 

Project Heartbeat used HTML 5, CSS, Django 3.2.16 and Python v3.11.
